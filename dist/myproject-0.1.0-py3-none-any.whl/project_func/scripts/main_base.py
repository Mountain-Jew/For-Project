
def main():
    print('Первая попытка запустить проект!')

if __name__ == '__main__':
    main()
